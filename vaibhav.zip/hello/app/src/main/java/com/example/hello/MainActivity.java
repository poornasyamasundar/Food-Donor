package com.example.hello;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private EditText edttextname,edttxtinstitute,edttxtmail,edttxtpass,
            edttxtrepass,edttxtaddress;
    private Button btnsubmit;
    private RadioGroup radioGroup;
    private CheckBox chkagree;
    private ConstraintLayout parent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();

        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initRegister();
            }
        });
    }

    private void initRegister(){
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
        dbHandler.loadHandler();
        if(validateData())
        {
            if(chkagree.isChecked()){
                //String Name,String Mail,String Pass,String Adress,String Institute,int gender
                RadioButton gender1 = findViewById(R.id.radiomale);
                RadioButton gender2 = findViewById(R.id.radiofemale);
                String s;
                if(gender1.isChecked())
                    s="Male";
                else if(gender2.isChecked())
                    s="Female";
                else
                    s="Other";
                client cl = new client(edttextname.getText().toString(),edttxtmail.getText().toString(),edttxtpass.getText().toString(),edttxtaddress.getText().toString(), edttxtinstitute.getText().toString(),s);
                dbHandler.addHandler(cl);
            }
            else
            {
                Toast.makeText(this, "You need to agree to the licence agrement", Toast.LENGTH_SHORT).show();
            }
            //to data base
        }
    }

    private boolean validateData(){
        if(edttextname.getText().toString().equals("")){
            return false;
        }
        if(edttxtmail.getText().toString().equals("")){
            return false;
        }
        if(edttxtpass.getText().toString().equals("")){
            return false;
        }
        if(edttxtrepass.getText().toString().equals("")){
            return false;
        }
        if(!edttxtpass.getText().toString().equals(edttxtrepass.getText().toString())){
            return false;
        }
        if(edttxtinstitute.getText().toString().equals("")){
            return false;
        }
        if(edttxtaddress.getText().toString().equals("")){
            return false;
        }
        return true;
    }

    private  void initViews(){
        Log.d(TAG, "initViews: initViews: Started");
        edttextname = findViewById(R.id.edttextname);
        edttxtinstitute = findViewById(R.id.edttxtinstitute);
        edttxtmail = findViewById(R.id.edttxtmail);
        edttxtpass = findViewById(R.id.edttxtpass);
        edttxtrepass = findViewById(R.id.edttxtrepass);
        edttxtaddress = findViewById(R.id.edttxtaddress);

        btnsubmit = findViewById(R.id.btnsubmit);

        radioGroup = findViewById(R.id.radioGroup);
        chkagree = findViewById(R.id.chkagree);
        parent = findViewById(R.id.parent);
    }
}