package com.example.hello;

import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.database.Cursor;

public class client {
    private String name;
    private String mail;
    private String pass;
    private String addres;
    private String institutename;
    private String gender;

    public client() {}
    public client(String Name,String Mail,String Pass,String Adress,String Institute,String gender) {
        this.name=Name;
        this.mail=Mail;
        this.pass=Pass;
        this.addres=Adress;
        this.institutename=Institute;
    }

    public String getName() { return name; }
    public String getMail(){ return mail; }
    public  String getPass(){ return pass; }
    public String getAddres(){ return addres; }
    public String getInstitutename(){ return institutename; }
    public String getGender() { return gender; }

    public void setName(String name) { this.name = name; }
    public void setMail(String mail) { this.mail = mail; }
    public  void setPass(String pass) { this.pass = pass;}
    public void setAddres(String addres) { this.addres = addres; }
    public void setInstitutename(String institutename) { this.institutename = institutename; }
    public void setGender(String gender) { this.gender = gender; }
}

