package com.example.hello;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDBHandler extends SQLiteOpenHelper {
    //information of database
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "clientDB.db";
    public static final String TABLE_NAME = "Client";
    public static final String COLUMN_NAME = "Name";
    public static final String COLUMN_MAIL = "Email";
    public static final String COLUMN_INSTITUTE = "InstitutionName";
    public static final String COLUMN_ADDRESS = "Address";
    public static final String COLUMN_PASSWORD = "Password";
    public static final String COLUMN_GENDER = "Gender";

    //initialize the database
    public MyDBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE " + "TABLE" + TABLE_NAME + "(" +
                COLUMN_NAME + "TEXT," +
                COLUMN_INSTITUTE + "TEXT," +
                COLUMN_MAIL + "TEXT PRIMARYKEY," +
                COLUMN_GENDER + "TEXT," +
                COLUMN_ADDRESS + "TEXT," +
                COLUMN_PASSWORD + "TEXT" +
                ")";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
    }

    public String loadHandler() {
        String result = "";
        String query = "Select * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            int result_0 = cursor.getInt(0);
            String result_1 = cursor.getString(1);
            result += String.valueOf(result_0) + " " + result_1 +
                    System.getProperty("line.separator");
        }
        cursor.close();
        db.close();
        return result;
    }

    public void addHandler(client cl) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, cl.getName());
        values.put(COLUMN_MAIL, cl.getMail());
        values.put(COLUMN_INSTITUTE, cl.getInstitutename());
        values.put(COLUMN_ADDRESS, cl.getAddres());
        values.put(COLUMN_PASSWORD, cl.getPass());
        values.put(COLUMN_GENDER, cl.getGender());
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public client findHandler(String name) {
        String query = "Select * FROM " + TABLE_NAME + "WHERE" + COLUMN_NAME + " = " + "'" + name + "'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        client cl = new client();
        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            cl.setName(cursor.getString(0));
            cl.setInstitutename(cursor.getString(1));
            cl.setMail(cursor.getString(2));
            cl.setGender(cursor.getString(3));
            cl.setAddres(cursor.getString(4));
            cl.setPass(cursor.getString(5));
            cursor.close();
        } else {
            cl = null;
        }
        db.close();
        return cl;
    }

}
